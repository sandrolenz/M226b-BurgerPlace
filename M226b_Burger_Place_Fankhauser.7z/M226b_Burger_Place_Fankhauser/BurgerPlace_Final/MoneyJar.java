import greenfoot.*;  

/**
 * The MoneyJar is just a decorative place to show the earned money.
 * 
 * @author Daniel Fankhauser
 * @version 1.1
 */
public class MoneyJar extends Actor
{
    private GreenfootImage img = new GreenfootImage("MoneyJar.png");
   
    /**
     * Act
     */
    public void act()
    {
        // Add your action code here.
    }
}
